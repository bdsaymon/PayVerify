package com.payverify.personal.data.repository

import android.content.Context
import com.payverify.personal.data.local.AppDatabase
import com.payverify.personal.data.local.entities.AccountEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AccountRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).accountDao()

    fun getAllAccounts(): Flow<List<AccountEntity>> = dao.getAllAccounts()

    suspend fun insert(account: AccountEntity) = withContext(Dispatchers.IO) { dao.insert(account) }

    suspend fun update(account: AccountEntity) = withContext(Dispatchers.IO) { dao.update(account) }

    suspend fun delete(account: AccountEntity) = withContext(Dispatchers.IO) { dao.delete(account) }

    suspend fun getById(id: String): AccountEntity? = withContext(Dispatchers.IO) { dao.getAccountById(id) }

    suspend fun getActiveAccounts(): List<AccountEntity> = withContext(Dispatchers.IO) { dao.getActiveAccounts() }
}
