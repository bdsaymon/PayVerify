package com.payverify.personal.data.repository

import android.content.Context
import com.payverify.personal.data.local.AppDatabase
import com.payverify.personal.data.local.entities.*
import com.payverify.personal.data.remote.RetrofitClient
import com.payverify.personal.data.remote.VerificationConfirmPayload
import com.payverify.personal.data.remote.WebhookPayload
import com.payverify.personal.utils.NotificationHelper
import com.payverify.personal.utils.TelegramNotifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PaymentRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val transactionDao = db.transactionDao()
    private val accountDao = db.accountDao()
    private val pendingDao = db.pendingVerificationDao()
    private val debugDao = db.debugLogDao()

    suspend fun processNewTransaction(parsed: com.payverify.personal.utils.ParsedSms, rawSms: String) {
        withContext(Dispatchers.IO) {
            try {
                val existing = transactionDao.findByTxnId(parsed.txnId)
                if (existing != null) {
                    NotificationHelper.showDuplicateNotification(context, parsed.txnId)
                    return@withContext
                }

                val account = accountDao.findAccountByNumber(parsed.receiverNumber)
                if (account == null) {
                    debugDao.insert(DebugLogEntity(
                        rawSms = rawSms,
                        sender = parsed.senderNumber,
                        reason = "NO_ACCOUNT_MATCH for receiver: ${parsed.receiverNumber}"
                    ))
                    return@withContext
                }

                val matchedPending = pendingDao.findMatchingPending(account.id, parsed.amount, parsed.gateway)

                val status = if (matchedPending != null) "VERIFIED" else "UNMATCHED"

                val txEntity = TransactionEntity(
                    txnId = parsed.txnId,
                    accountId = account.id,
                    amount = parsed.amount,
                    senderNumber = parsed.senderNumber,
                    receiverNumber = parsed.receiverNumber,
                    gateway = parsed.gateway,
                    status = status,
                    rawSms = rawSms
                )
                transactionDao.insert(txEntity)

                if (matchedPending != null) {
                    pendingDao.updateStatus(matchedPending.id, "VERIFIED", parsed.txnId)
                    NotificationHelper.showVerifiedNotification(context, account.accountName, parsed.txnId, parsed.amount, parsed.gateway)
                    sendVerificationConfirm(account, matchedPending, parsed.txnId)
                } else {
                    NotificationHelper.showPendingNotification(context, account.accountName, parsed.txnId, parsed.amount, parsed.gateway)
                }

                sendWebhook(account, txEntity)

                if (account.telegramBotToken.isNotBlank() && status == "VERIFIED") {
                    TelegramNotifier.sendPaymentAlert(
                        account.telegramBotToken,
                        account.telegramChatId,
                        account.accountName,
                        parsed.txnId,
                        parsed.amount,
                        parsed.senderNumber,
                        parsed.gateway
                    )
                }
            } catch (e: Exception) {
                debugDao.insert(DebugLogEntity(rawSms = rawSms, sender = "", reason = "EXCEPTION: ${e.message}"))
            }
        }
    }

    private suspend fun sendWebhook(account: AccountEntity, tx: TransactionEntity) {
        if (account.webhookUrl.isBlank()) return
        try {
            RetrofitClient.webhookService.sendWebhook(
                url = account.webhookUrl,
                secret = account.webhookSecretKey,
                payload = WebhookPayload(
                    txnId = tx.txnId,
                    amount = tx.amount,
                    sender = tx.senderNumber,
                    gateway = tx.gateway,
                    timestamp = tx.timestamp,
                    accountId = account.id,
                    status = tx.status
                )
            )
        } catch (e: Exception) {
            // Silent fail, log if needed
        }
    }

    private suspend fun sendVerificationConfirm(account: AccountEntity, pending: PendingVerificationEntity, txnId: String) {
        if (account.webhookUrl.isBlank()) return
        try {
            RetrofitClient.webhookService.sendVerificationConfirm(
                url = account.webhookUrl,
                secret = account.webhookSecretKey,
                apiKey = account.integrationApiKey,
                payload = VerificationConfirmPayload(
                    orderId = pending.orderId,
                    txnId = txnId,
                    amount = pending.expectedAmount,
                    gateway = pending.gateway,
                    status = "VERIFIED",
                    timestamp = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            // Silent fail
        }
    }

    fun getTransactionsByAccount(accountId: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByAccount(accountId)

    fun getLatestTransactions(accountId: String): Flow<List<TransactionEntity>> =
        transactionDao.getLatestTransactions(accountId)

    fun getTodayTotal(accountId: String, startOfDay: Long): Flow<Double?> =
        transactionDao.getTodayTotal(accountId, startOfDay)

    fun getTodayCount(accountId: String, startOfDay: Long): Flow<Int> =
        transactionDao.getTodayCount(accountId, startOfDay)

    fun searchTransactions(accountId: String, query: String): Flow<List<TransactionEntity>> =
        transactionDao.searchTransactions(accountId, query)

    fun filterByGateway(accountId: String, gateway: String): Flow<List<TransactionEntity>> =
        transactionDao.filterByGateway(accountId, gateway)

    suspend fun insertManual(tx: TransactionEntity): Boolean {
        return withContext(Dispatchers.IO) {
            val existing = transactionDao.findByTxnId(tx.txnId)
            if (existing != null) false
            else {
                transactionDao.insert(tx)
                true
            }
        }
    }

    suspend fun updateTransactionStatus(txnId: String, status: String) {
        withContext(Dispatchers.IO) { transactionDao.updateStatus(txnId, status) }
    }

    suspend fun getTransactionsInRange(accountId: String, from: Long, to: Long) =
        withContext(Dispatchers.IO) { transactionDao.getTransactionsInRange(accountId, from, to) }
}
