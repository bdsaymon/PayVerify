package com.payverify.personal.utils

import android.content.Context
import android.os.Environment
import com.payverify.personal.data.local.entities.TransactionEntity
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

object CsvExporter {

    fun exportTransactions(context: Context, transactions: List<TransactionEntity>, accountName: String): File? {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
            val fileName = "PayVerify_${accountName}_${sdf.format(Date())}.csv"
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)

            val writer = FileWriter(file)
            writer.append("TxnID,Amount,Sender,Gateway,Status,Timestamp\n")
            val dateSdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            for (tx in transactions) {
                writer.append("${tx.txnId},${tx.amount},${tx.senderNumber},${tx.gateway},${tx.status},${dateSdf.format(Date(tx.timestamp))}\n")
            }
            writer.flush()
            writer.close()
            file
        } catch (e: Exception) {
            null
        }
    }
}
