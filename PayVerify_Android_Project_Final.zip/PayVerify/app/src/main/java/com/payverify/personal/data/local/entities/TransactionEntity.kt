package com.payverify.personal.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val txnId: String,
    val accountId: String,
    val amount: Double,
    val senderNumber: String,
    val receiverNumber: String,
    val gateway: String,
    val status: String = "UNMATCHED",
    val rawSms: String = "",
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
