package com.payverify.personal.ui.accounts

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.payverify.personal.data.local.entities.AccountEntity
import com.payverify.personal.databinding.ActivityAccountsBinding
import com.payverify.personal.service.SmsListenerService
import com.payverify.personal.ui.dashboard.DashboardActivity
import com.payverify.personal.ui.settings.AccountEditActivity
import com.payverify.personal.ui.settings.MasterPinActivity
import kotlinx.coroutines.launch

class AccountsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAccountsBinding
    private val viewModel: AccountsViewModel by viewModels()
    private lateinit var adapter: AccountCardAdapter

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        val smsGranted = perms[Manifest.permission.RECEIVE_SMS] == true && perms[Manifest.permission.READ_SMS] == true
        if (!smsGranted) Toast.makeText(this, "SMS permission required for payment tracking", Toast.LENGTH_LONG).show()
        startSmsService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccountsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = "PayVerify Accounts"

        setupRecyclerView()
        observeAccounts()
        requestPermissionsIfNeeded()

        binding.fabAddAccount.setOnClickListener {
            val intent = Intent(this, AccountEditActivity::class.java)
            intent.putExtra("mode", "create")
            startActivity(intent)
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, MasterPinActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = AccountCardAdapter(
            onAccountClick = { account ->
                val intent = Intent(this, DashboardActivity::class.java)
                intent.putExtra("accountId", account.id)
                startActivity(intent)
            },
            onEditClick = { account ->
                val intent = Intent(this, AccountEditActivity::class.java)
                intent.putExtra("mode", "edit")
                intent.putExtra("accountId", account.id)
                startActivity(intent)
            },
            onDeleteClick = { account ->
                AlertDialog.Builder(this)
                    .setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete '${account.accountName}'? All transactions will be lost.")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteAccount(account) }
                    .setNegativeButton("Cancel", null)
                    .show()
            },
            onToggleActive = { account ->
                viewModel.updateAccount(account.copy(isActive = !account.isActive))
            }
        )
        binding.recyclerAccounts.layoutManager = LinearLayoutManager(this)
        binding.recyclerAccounts.adapter = adapter
    }

    private fun observeAccounts() {
        lifecycleScope.launch {
            viewModel.accounts.collect { accounts ->
                adapter.submitList(accounts)
                binding.tvEmptyState.visibility = if (accounts.isEmpty())
                    android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            permissionLauncher.launch(notGranted.toTypedArray())
        } else {
            startSmsService()
        }
    }

    private fun startSmsService() {
        val intent = Intent(this, SmsListenerService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }
}
