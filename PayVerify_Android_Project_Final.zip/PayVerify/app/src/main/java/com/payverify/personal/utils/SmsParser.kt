package com.payverify.personal.utils

data class ParsedSms(
    val txnId: String,
    val amount: Double,
    val senderNumber: String,
    val receiverNumber: String,
    val gateway: String
)

object SmsParser {

    private val BKASH_PATTERN = Regex(
        """(?:You have received|Tk received from|received Tk)\s*(?:Tk\s*)?([\d,]+\.?\d*)\s*(?:from|BDT from)\s*(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8}).*?TxnID\s*([A-Z0-9]{10})""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    private val BKASH_PATTERN_2 = Regex(
        """TxnID\s*([A-Z0-9]{10}).*?Tk\s*([\d,]+\.?\d*).*?(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8})""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    private val BKASH_RECEIVER_PATTERN = Regex(
        """bKash Account\s*(?:No\.?\s*)?(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8})""",
        setOf(RegexOption.IGNORE_CASE)
    )

    private val NAGAD_PATTERN = Regex(
        """(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8})\s*থেকে\s*([\d,]+\.?\d*)\s*টাকা.*?Ref[:\s]*([A-Z0-9]{8,10})""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    private val NAGAD_PATTERN_2 = Regex(
        """Ref[:\s]*([A-Z0-9]{8,10}).*?(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8}).*?([\d,]+\.?\d*)\s*(?:Taka|BDT|টাকা)""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    private val NAGAD_RECEIVER_PATTERN = Regex(
        """আপনার\s+(?:একাউন্টে|Account)\s*(\+?880?1[3-9]\d{8}|\+?01[3-9]\d{8})""",
        setOf(RegexOption.IGNORE_CASE)
    )

    fun parseBkash(smsBody: String, smsSender: String): ParsedSms? {
        return try {
            var match = BKASH_PATTERN.find(smsBody)
            if (match != null) {
                val amount = match.groupValues[1].replace(",", "").toDoubleOrNull() ?: return null
                val sender = normalizeNumber(match.groupValues[2])
                val txnId = match.groupValues[3]
                val receiver = findBkashReceiver(smsBody)
                ParsedSms(txnId, amount, sender, receiver, "bkash")
            } else {
                match = BKASH_PATTERN_2.find(smsBody)
                if (match != null) {
                    val txnId = match.groupValues[1]
                    val amount = match.groupValues[2].replace(",", "").toDoubleOrNull() ?: return null
                    val sender = normalizeNumber(match.groupValues[3])
                    val receiver = findBkashReceiver(smsBody)
                    ParsedSms(txnId, amount, sender, receiver, "bkash")
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun parseNagad(smsBody: String, smsSender: String): ParsedSms? {
        return try {
            var match = NAGAD_PATTERN.find(smsBody)
            if (match != null) {
                val sender = normalizeNumber(match.groupValues[1])
                val amount = match.groupValues[2].replace(",", "").toDoubleOrNull() ?: return null
                val txnId = match.groupValues[3]
                val receiver = findNagadReceiver(smsBody)
                ParsedSms(txnId, amount, sender, receiver, "nagad")
            } else {
                match = NAGAD_PATTERN_2.find(smsBody)
                if (match != null) {
                    val txnId = match.groupValues[1]
                    val sender = normalizeNumber(match.groupValues[2])
                    val amount = match.groupValues[3].replace(",", "").toDoubleOrNull() ?: return null
                    val receiver = findNagadReceiver(smsBody)
                    ParsedSms(txnId, amount, sender, receiver, "nagad")
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun findBkashReceiver(smsBody: String): String {
        return try {
            BKASH_RECEIVER_PATTERN.find(smsBody)?.groupValues?.get(1)?.let {
                normalizeNumber(it)
            } ?: ""
        } catch (e: Exception) { "" }
    }

    private fun findNagadReceiver(smsBody: String): String {
        return try {
            NAGAD_RECEIVER_PATTERN.find(smsBody)?.groupValues?.get(1)?.let {
                normalizeNumber(it)
            } ?: ""
        } catch (e: Exception) { "" }
    }

    private fun normalizeNumber(number: String): String {
        return try {
            val digits = number.replace(Regex("[^0-9]"), "")
            when {
                digits.startsWith("880") && digits.length == 13 -> "0${digits.substring(3)}"
                digits.startsWith("88") && digits.length == 13 -> "0${digits.substring(2)}"
                digits.length == 11 && digits.startsWith("01") -> digits
                else -> digits
            }
        } catch (e: Exception) { number }
    }

    fun isBkash(sender: String): Boolean {
        return sender.contains("bKash", ignoreCase = true) ||
               sender.contains("bkash", ignoreCase = true)
    }

    fun isNagad(sender: String): Boolean {
        return sender.contains("Nagad", ignoreCase = true) ||
               sender.contains("NAGAD", ignoreCase = true)
    }
}
