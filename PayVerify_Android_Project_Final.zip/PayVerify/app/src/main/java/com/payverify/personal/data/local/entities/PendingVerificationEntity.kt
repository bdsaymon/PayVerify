package com.payverify.personal.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "pending_verifications")
data class PendingVerificationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val accountId: String,
    val orderId: String,
    val expectedAmount: Double,
    val customerPhone: String,
    val gateway: String,
    val status: String = "PENDING",
    val matchedTxnId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (10 * 60 * 1000)
)
