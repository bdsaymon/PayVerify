package com.payverify.personal.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.payverify.personal.utils.NotificationHelper

class SmsListenerService : Service() {

    companion object {
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationHelper.buildServiceNotification(this)
        startForeground(NOTIFICATION_ID, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        val restartIntent = Intent(this, SmsListenerService::class.java)
        startService(restartIntent)
    }
}
