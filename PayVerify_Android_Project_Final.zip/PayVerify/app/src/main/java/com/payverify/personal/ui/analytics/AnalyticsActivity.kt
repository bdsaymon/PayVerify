package com.payverify.personal.ui.analytics

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.payverify.personal.data.repository.PaymentRepository
import com.payverify.personal.databinding.ActivityAnalyticsBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AnalyticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalyticsBinding
    private val repo by lazy { PaymentRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalyticsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Analytics"

        val accountId = intent.getStringExtra("accountId") ?: run { finish(); return }
        loadAnalytics(accountId)
    }

    private fun loadAnalytics(accountId: String) {
        lifecycleScope.launch {
            val sdf = SimpleDateFormat("EEE", Locale.getDefault())
            val calendar = Calendar.getInstance()
            val labels = mutableListOf<String>()
            val entries = mutableListOf<BarEntry>()

            for (i in 6 downTo 0) {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, -i)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                val start = cal.timeInMillis
                cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59)
                cal.set(Calendar.SECOND, 59)
                val end = cal.timeInMillis

                val txs = repo.getTransactionsInRange(accountId, start, end)
                val total = txs.sumOf { it.amount }.toFloat()
                entries.add(BarEntry((6 - i).toFloat(), total))
                labels.add(sdf.format(cal.time))
            }

            val dataSet = BarDataSet(entries, "Daily Total (Tk)").apply {
                color = Color.parseColor("#4CAF50")
                valueTextColor = Color.WHITE
                valueTextSize = 10f
            }

            binding.barChart.apply {
                data = BarData(dataSet)
                xAxis.valueFormatter = IndexAxisValueFormatter(labels)
                xAxis.granularity = 1f
                xAxis.textColor = Color.WHITE
                axisLeft.textColor = Color.WHITE
                axisRight.isEnabled = false
                legend.textColor = Color.WHITE
                description.isEnabled = false
                setBackgroundColor(Color.TRANSPARENT)
                animateY(800)
                invalidate()
            }

            val allTx = repo.getTransactionsInRange(accountId,
                System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000L,
                System.currentTimeMillis())

            binding.tvWeekTotal.text = "This Week: Tk %.2f".format(allTx.sumOf { it.amount })
            binding.tvVerifiedCount.text = "Verified: ${allTx.count { it.status == "VERIFIED" }}"
            binding.tvRejectedCount.text = "Rejected: ${allTx.count { it.status == "REJECTED" }}"
            binding.tvTotalCount.text = "Total Transactions: ${allTx.size}"
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
