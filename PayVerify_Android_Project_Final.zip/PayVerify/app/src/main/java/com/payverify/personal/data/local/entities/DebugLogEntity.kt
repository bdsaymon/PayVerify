package com.payverify.personal.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "debug_logs")
data class DebugLogEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val rawSms: String,
    val sender: String,
    val reason: String,
    val timestamp: Long = System.currentTimeMillis()
)
