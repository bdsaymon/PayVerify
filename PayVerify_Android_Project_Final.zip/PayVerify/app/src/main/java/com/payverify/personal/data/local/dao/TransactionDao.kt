package com.payverify.personal.data.local.dao

import androidx.room.*
import com.payverify.personal.data.local.entities.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(transaction: TransactionEntity): Long

    @Update
    suspend fun update(transaction: TransactionEntity)

    @Delete
    suspend fun delete(transaction: TransactionEntity)

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY timestamp DESC")
    fun getTransactionsByAccount(accountId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY timestamp DESC LIMIT 5")
    fun getLatestTransactions(accountId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE txnId = :txnId LIMIT 1")
    suspend fun findByTxnId(txnId: String): TransactionEntity?

    @Query("SELECT SUM(amount) FROM transactions WHERE accountId = :accountId AND timestamp >= :startOfDay AND status = 'VERIFIED'")
    fun getTodayTotal(accountId: String, startOfDay: Long): Flow<Double?>

    @Query("SELECT COUNT(*) FROM transactions WHERE accountId = :accountId AND timestamp >= :startOfDay")
    fun getTodayCount(accountId: String, startOfDay: Long): Flow<Int>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND (txnId LIKE '%' || :query || '%' OR senderNumber LIKE '%' || :query || '%') ORDER BY timestamp DESC")
    fun searchTransactions(accountId: String, query: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND gateway = :gateway ORDER BY timestamp DESC")
    fun filterByGateway(accountId: String, gateway: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND status = :status ORDER BY timestamp DESC")
    fun filterByStatus(accountId: String, status: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND timestamp >= :from AND timestamp <= :to ORDER BY timestamp DESC")
    suspend fun getTransactionsInRange(accountId: String, from: Long, to: Long): List<TransactionEntity>

    @Query("UPDATE transactions SET status = :status WHERE txnId = :txnId")
    suspend fun updateStatus(txnId: String, status: String)
}
