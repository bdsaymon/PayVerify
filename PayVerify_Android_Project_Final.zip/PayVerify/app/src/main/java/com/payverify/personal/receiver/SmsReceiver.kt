package com.payverify.personal.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.payverify.personal.data.repository.PaymentRepository
import com.payverify.personal.utils.SmsParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        try {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (messages.isNullOrEmpty()) return

            val sender = messages[0].originatingAddress ?: return
            val smsBody = messages.joinToString("") { it.messageBody ?: "" }

            if (smsBody.isBlank()) return

            val parsed = when {
                SmsParser.isBkash(sender) -> SmsParser.parseBkash(smsBody, sender)
                SmsParser.isNagad(sender) -> SmsParser.parseNagad(smsBody, sender)
                else -> null
            } ?: return

            val repo = PaymentRepository(context)
            CoroutineScope(Dispatchers.IO).launch {
                repo.processNewTransaction(parsed, smsBody)
            }
        } catch (e: Exception) {
            // Prevent any crash from propagating
        }
    }
}
