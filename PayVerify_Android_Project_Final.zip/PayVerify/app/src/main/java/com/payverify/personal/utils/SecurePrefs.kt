package com.payverify.personal.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecurePrefs {

    private const val PREFS_NAME = "payverify_secure_prefs"
    private const val KEY_MASTER_PIN = "master_pin"
    private const val KEY_PIN_FAIL_COUNT = "pin_fail_count"
    private const val KEY_PIN_LOCK_UNTIL = "pin_lock_until"

    private fun getPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getMasterPin(context: Context): String {
        return getPrefs(context).getString(KEY_MASTER_PIN, "1234") ?: "1234"
    }

    fun setMasterPin(context: Context, pin: String) {
        getPrefs(context).edit().putString(KEY_MASTER_PIN, pin).apply()
    }

    fun getFailCount(context: Context): Int {
        return getPrefs(context).getInt(KEY_PIN_FAIL_COUNT, 0)
    }

    fun setFailCount(context: Context, count: Int) {
        getPrefs(context).edit().putInt(KEY_PIN_FAIL_COUNT, count).apply()
    }

    fun getLockUntil(context: Context): Long {
        return getPrefs(context).getLong(KEY_PIN_LOCK_UNTIL, 0L)
    }

    fun setLockUntil(context: Context, time: Long) {
        getPrefs(context).edit().putLong(KEY_PIN_LOCK_UNTIL, time).apply()
    }

    fun isLocked(context: Context): Boolean {
        return System.currentTimeMillis() < getLockUntil(context)
    }

    fun getRemainingLockSeconds(context: Context): Long {
        val remaining = getLockUntil(context) - System.currentTimeMillis()
        return if (remaining > 0) remaining / 1000 else 0
    }
}
