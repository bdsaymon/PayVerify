package com.payverify.personal.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.payverify.personal.data.local.dao.*
import com.payverify.personal.data.local.entities.*

@Database(
    entities = [
        TransactionEntity::class,
        AccountEntity::class,
        PendingVerificationEntity::class,
        DebugLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun transactionDao(): TransactionDao
    abstract fun accountDao(): AccountDao
    abstract fun pendingVerificationDao(): PendingVerificationDao
    abstract fun debugLogDao(): DebugLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "payverify_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
