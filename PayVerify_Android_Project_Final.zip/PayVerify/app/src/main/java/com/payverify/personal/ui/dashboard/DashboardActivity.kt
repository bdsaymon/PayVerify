package com.payverify.personal.ui.dashboard

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.payverify.personal.databinding.ActivityDashboardBinding
import com.payverify.personal.ui.history.HistoryActivity
import com.payverify.personal.ui.history.TransactionAdapter
import com.payverify.personal.ui.integration.IntegrationPinActivity
import com.payverify.personal.ui.manual.ManualEntryActivity
import com.payverify.personal.ui.analytics.AnalyticsActivity
import kotlinx.coroutines.launch

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var adapter: TransactionAdapter
    private var accountId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        accountId = intent.getStringExtra("accountId") ?: run { finish(); return }

        setupRecyclerView()
        observeState()
        viewModel.loadAccount(accountId)

        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadAccount(accountId)
            binding.swipeRefresh.isRefreshing = false
        }

        binding.btnViewAll.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            intent.putExtra("accountId", accountId)
            startActivity(intent)
        }

        binding.btnManualEntry.setOnClickListener {
            val intent = Intent(this, ManualEntryActivity::class.java)
            intent.putExtra("accountId", accountId)
            startActivity(intent)
        }

        binding.btnAnalytics.setOnClickListener {
            val intent = Intent(this, AnalyticsActivity::class.java)
            intent.putExtra("accountId", accountId)
            startActivity(intent)
        }

        binding.btnIntegration.setOnClickListener {
            val intent = Intent(this, IntegrationPinActivity::class.java)
            intent.putExtra("accountId", accountId)
            startActivity(intent)
        }
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter { tx ->
            val intent = Intent(this, com.payverify.personal.ui.detail.TransactionDetailActivity::class.java)
            intent.putExtra("txnId", tx.txnId)
            startActivity(intent)
        }
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(this)
        binding.recyclerTransactions.adapter = adapter
    }

    private fun observeState() {
        lifecycleScope.launch {
            viewModel.account.collect { account ->
                account?.let {
                    title = it.accountName
                    supportActionBar?.subtitle = "bKash: ${it.bkashNumber} | Nagad: ${it.nagadNumber}"
                }
            }
        }
        lifecycleScope.launch {
            viewModel.transactions.collect { adapter.submitList(it) }
        }
        lifecycleScope.launch {
            viewModel.todayTotal.collect { binding.tvTodayTotal.text = "Tk %.2f".format(it) }
        }
        lifecycleScope.launch {
            viewModel.todayCount.collect { binding.tvTodayCount.text = "$it Transactions" }
        }
    }
}
