package com.payverify.personal.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.payverify.personal.data.local.entities.TransactionEntity
import com.payverify.personal.databinding.ItemTransactionBinding
import java.text.SimpleDateFormat
import java.util.*

class TransactionAdapter(
    private val onItemClick: (TransactionEntity) -> Unit
) : ListAdapter<TransactionEntity, TransactionAdapter.ViewHolder>(DiffCallback()) {

    private val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    inner class ViewHolder(private val binding: ItemTransactionBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tx: TransactionEntity) {
            binding.tvTxnId.text = tx.txnId
            binding.tvAmount.text = "Tk %.2f".format(tx.amount)
            binding.tvSender.text = "From: ${tx.senderNumber}"
            binding.tvGateway.text = tx.gateway.uppercase()
            binding.tvTime.text = sdf.format(Date(tx.timestamp))
            binding.tvStatus.text = when (tx.status) {
                "VERIFIED" -> "✅ Verified"
                "UNMATCHED" -> "⏳ Pending"
                "EXPIRED" -> "❌ Expired"
                "REJECTED" -> "🚫 Rejected"
                else -> tx.status
            }
            val statusColor = when (tx.status) {
                "VERIFIED" -> 0xFF4CAF50.toInt()
                "UNMATCHED" -> 0xFFFFA000.toInt()
                "EXPIRED", "REJECTED" -> 0xFFF44336.toInt()
                else -> 0xFF9E9E9E.toInt()
            }
            binding.tvStatus.setTextColor(statusColor)
            binding.root.setOnClickListener { onItemClick(tx) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTransactionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    class DiffCallback : DiffUtil.ItemCallback<TransactionEntity>() {
        override fun areItemsTheSame(a: TransactionEntity, b: TransactionEntity) = a.txnId == b.txnId
        override fun areContentsTheSame(a: TransactionEntity, b: TransactionEntity) = a == b
    }
}
