package com.payverify.personal.ui.history

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.payverify.personal.databinding.ActivityHistoryBinding
import com.payverify.personal.ui.detail.TransactionDetailActivity
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val viewModel: HistoryViewModel by viewModels()
    private lateinit var adapter: TransactionAdapter
    private var accountId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Transaction History"

        accountId = intent.getStringExtra("accountId") ?: run { finish(); return }

        adapter = TransactionAdapter { tx ->
            val intent = Intent(this, TransactionDetailActivity::class.java)
            intent.putExtra("txnId", tx.txnId)
            startActivity(intent)
        }
        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        binding.recyclerHistory.adapter = adapter

        viewModel.loadAll(accountId)

        lifecycleScope.launch {
            viewModel.transactions.collect { adapter.submitList(it) }
        }

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                val q = newText?.trim() ?: ""
                if (q.isBlank()) viewModel.loadAll(accountId)
                else viewModel.search(accountId, q)
                return true
            }
        })

        binding.chipAll.setOnClickListener { viewModel.loadAll(accountId) }
        binding.chipBkash.setOnClickListener { viewModel.filterByGateway(accountId, "bkash") }
        binding.chipNagad.setOnClickListener { viewModel.filterByGateway(accountId, "nagad") }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
