package com.payverify.personal.ui.manual

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.payverify.personal.data.local.entities.TransactionEntity
import com.payverify.personal.data.repository.AccountRepository
import com.payverify.personal.data.repository.PaymentRepository
import com.payverify.personal.databinding.ActivityManualEntryBinding
import kotlinx.coroutines.launch

class ManualEntryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityManualEntryBinding
    private val payRepo by lazy { PaymentRepository(this) }
    private val accountRepo by lazy { AccountRepository(this) }
    private var selectedAccountId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManualEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Manual Entry"

        selectedAccountId = intent.getStringExtra("accountId") ?: ""

        loadAccounts()

        binding.btnSubmit.setOnClickListener { submitManualEntry() }
    }

    private fun loadAccounts() {
        lifecycleScope.launch {
            val accounts = accountRepo.getActiveAccounts()
            if (accounts.isEmpty()) {
                Toast.makeText(this@ManualEntryActivity, "No active accounts found", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            val names = accounts.map { it.accountName }
            val adapter = ArrayAdapter(this@ManualEntryActivity, android.R.layout.simple_spinner_item, names)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerAccount.adapter = adapter

            val preSelected = accounts.indexOfFirst { it.id == selectedAccountId }
            if (preSelected >= 0) binding.spinnerAccount.setSelection(preSelected)

            binding.btnSubmit.setOnClickListener {
                val idx = binding.spinnerAccount.selectedItemPosition
                selectedAccountId = accounts[idx].id
                submitManualEntry()
            }
        }
    }

    private fun submitManualEntry() {
        val txnId = binding.etTxnId.text.toString().trim()
        val amountStr = binding.etAmount.text.toString().trim()
        val sender = binding.etSender.text.toString().trim()
        val gateway = if (binding.radioBkash.isChecked) "bkash" else "nagad"
        val note = binding.etNote.text.toString().trim()

        if (txnId.isBlank() || amountStr.isBlank() || sender.isBlank()) {
            Toast.makeText(this, "TxnID, Amount, and Sender are required", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull() ?: run {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedAccountId.isBlank()) {
            Toast.makeText(this, "Please select an account", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            val tx = TransactionEntity(
                txnId = txnId,
                accountId = selectedAccountId,
                amount = amount,
                senderNumber = sender,
                receiverNumber = "",
                gateway = gateway,
                status = "VERIFIED",
                note = note,
                rawSms = "Manual Entry"
            )
            val success = payRepo.insertManual(tx)
            if (success) {
                Toast.makeText(this@ManualEntryActivity, "Transaction added successfully!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this@ManualEntryActivity, "Duplicate TxnID! Transaction already exists.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
