package com.payverify.personal.ui.detail

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.payverify.personal.data.local.AppDatabase
import com.payverify.personal.data.repository.PaymentRepository
import com.payverify.personal.databinding.ActivityTransactionDetailBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class TransactionDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTransactionDetailBinding
    private val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTransactionDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Transaction Detail"

        val txnId = intent.getStringExtra("txnId") ?: run { finish(); return }
        val repo = PaymentRepository(this)
        val dao = AppDatabase.getInstance(this).transactionDao()

        lifecycleScope.launch {
            val tx = dao.findByTxnId(txnId) ?: run { finish(); return@launch }
            binding.tvTxnId.text = "TxnID: ${tx.txnId}"
            binding.tvAmount.text = "Amount: Tk %.2f".format(tx.amount)
            binding.tvSender.text = "From: ${tx.senderNumber}"
            binding.tvReceiver.text = "To: ${tx.receiverNumber.ifBlank { "N/A" }}"
            binding.tvGateway.text = "Gateway: ${tx.gateway.uppercase()}"
            binding.tvStatus.text = "Status: ${tx.status}"
            binding.tvTime.text = "Time: ${sdf.format(Date(tx.timestamp))}"
            binding.tvNote.text = "Note: ${tx.note.ifBlank { "None" }}"
            binding.tvRawSms.text = "Raw SMS: ${tx.rawSms.ifBlank { "N/A" }}"

            binding.btnMarkVerified.setOnClickListener {
                lifecycleScope.launch {
                    repo.updateTransactionStatus(tx.txnId, "VERIFIED")
                    Toast.makeText(this@TransactionDetailActivity, "Marked as Verified", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }

            binding.btnMarkRejected.setOnClickListener {
                lifecycleScope.launch {
                    repo.updateTransactionStatus(tx.txnId, "REJECTED")
                    Toast.makeText(this@TransactionDetailActivity, "Marked as Rejected", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
