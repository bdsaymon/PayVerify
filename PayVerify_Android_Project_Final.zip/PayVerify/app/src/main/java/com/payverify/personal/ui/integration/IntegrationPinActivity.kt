package com.payverify.personal.ui.integration

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.payverify.personal.data.repository.AccountRepository
import com.payverify.personal.databinding.ActivityPinEntryBinding
import kotlinx.coroutines.launch

class IntegrationPinActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinEntryBinding
    private var enteredPin = ""
    private var accountId = ""
    private var correctPin = "0000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        accountId = intent.getStringExtra("accountId") ?: run { finish(); return }
        binding.tvTitle.text = "Integration Access"
        binding.tvSubtitle.text = "Enter Integration PIN for this account"

        val repo = AccountRepository(this)
        lifecycleScope.launch {
            correctPin = repo.getById(accountId)?.integrationPin ?: "0000"
        }

        setupKeypad()
        binding.btnConfirm.setOnClickListener { verifyPin() }
    }

    private fun setupKeypad() {
        val buttons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )
        buttons.forEachIndexed { index, btn ->
            btn.setOnClickListener {
                if (enteredPin.length < 4) {
                    enteredPin += index.toString()
                    updateDots()
                    if (enteredPin.length == 4) verifyPin()
                }
            }
        }
        binding.btnBackspace.setOnClickListener {
            if (enteredPin.isNotEmpty()) {
                enteredPin = enteredPin.dropLast(1)
                updateDots()
            }
        }
    }

    private fun updateDots() {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { i, dot -> dot.alpha = if (i < enteredPin.length) 1f else 0.3f }
    }

    private fun verifyPin() {
        if (enteredPin == correctPin) {
            val intent = Intent(this, IntegrationHubActivity::class.java)
            intent.putExtra("accountId", accountId)
            startActivity(intent)
            finish()
        } else {
            enteredPin = ""
            updateDots()
            binding.tvError.text = "Incorrect PIN. Try again."
            Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
        }
    }
}
