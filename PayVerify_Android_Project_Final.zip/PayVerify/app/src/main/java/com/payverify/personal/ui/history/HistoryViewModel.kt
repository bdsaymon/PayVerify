package com.payverify.personal.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.payverify.personal.data.local.entities.TransactionEntity
import com.payverify.personal.data.repository.PaymentRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = PaymentRepository(application)

    private val _transactions = MutableStateFlow<List<TransactionEntity>>(emptyList())
    val transactions: StateFlow<List<TransactionEntity>> = _transactions.asStateFlow()

    fun loadAll(accountId: String) {
        viewModelScope.launch {
            repo.getTransactionsByAccount(accountId).collect { _transactions.value = it }
        }
    }

    fun search(accountId: String, query: String) {
        viewModelScope.launch {
            repo.searchTransactions(accountId, query).collect { _transactions.value = it }
        }
    }

    fun filterByGateway(accountId: String, gateway: String) {
        viewModelScope.launch {
            if (gateway == "ALL") {
                repo.getTransactionsByAccount(accountId).collect { _transactions.value = it }
            } else {
                repo.filterByGateway(accountId, gateway.lowercase()).collect { _transactions.value = it }
            }
        }
    }
}
