package com.payverify.personal.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType

object TelegramNotifier {

    private val client = OkHttpClient()

    suspend fun sendPaymentAlert(
        botToken: String,
        chatId: String,
        accountName: String,
        txnId: String,
        amount: Double,
        sender: String,
        gateway: String
    ) {
        if (botToken.isBlank() || chatId.isBlank()) return
        withContext(Dispatchers.IO) {
            try {
                val message = "✅ Payment Verified\n" +
                        "Account: $accountName\n" +
                        "Gateway: ${gateway.uppercase()}\n" +
                        "TxnID: $txnId\n" +
                        "Amount: Tk $amount\n" +
                        "From: $sender"

                val url = "https://api.telegram.org/bot$botToken/sendMessage"
                val json = """{"chat_id":"$chatId","text":"$message"}"""
                val body = json.toRequestBody("application/json".toMediaType())
                val request = Request.Builder().url(url).post(body).build()
                client.newCall(request).execute().close()
            } catch (e: Exception) {
                // Silent fail
            }
        }
    }
}
