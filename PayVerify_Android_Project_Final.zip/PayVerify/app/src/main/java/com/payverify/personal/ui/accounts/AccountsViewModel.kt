package com.payverify.personal.ui.accounts

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.payverify.personal.data.local.entities.AccountEntity
import com.payverify.personal.data.repository.AccountRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountsViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AccountRepository(application)

    val accounts: StateFlow<List<AccountEntity>> = repo.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addAccount(account: AccountEntity) = viewModelScope.launch { repo.insert(account) }

    fun updateAccount(account: AccountEntity) = viewModelScope.launch { repo.update(account) }

    fun deleteAccount(account: AccountEntity) = viewModelScope.launch { repo.delete(account) }
}
