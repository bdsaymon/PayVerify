package com.payverify.personal.ui.settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.payverify.personal.data.local.entities.AccountEntity
import com.payverify.personal.data.repository.AccountRepository
import com.payverify.personal.databinding.ActivityAccountEditBinding
import kotlinx.coroutines.launch

class AccountEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAccountEditBinding
    private lateinit var repo: AccountRepository
    private var mode = "create"
    private var accountId = ""
    private var existingAccount: AccountEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccountEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        repo = AccountRepository(this)
        mode = intent.getStringExtra("mode") ?: "create"
        accountId = intent.getStringExtra("accountId") ?: ""

        title = if (mode == "create") "New Account" else "Edit Account"

        if (mode == "edit" && accountId.isNotBlank()) {
            lifecycleScope.launch {
                existingAccount = repo.getById(accountId)
                existingAccount?.let { populateFields(it) }
            }
        }

        binding.btnSave.setOnClickListener { saveAccount() }
    }

    private fun populateFields(account: AccountEntity) {
        binding.etAccountName.setText(account.accountName)
        binding.etBkashNumber.setText(account.bkashNumber)
        binding.etNagadNumber.setText(account.nagadNumber)
        binding.etWebhookUrl.setText(account.webhookUrl)
        binding.etWebhookSecret.setText(account.webhookSecretKey)
        binding.etSupabaseUrl.setText(account.supabaseUrl)
        binding.etSupabaseKey.setText(account.supabaseAnonKey)
        binding.etIntegrationPin.setText(account.integrationPin)
        binding.etTelegramToken.setText(account.telegramBotToken)
        binding.etTelegramChatId.setText(account.telegramChatId)
    }

    private fun saveAccount() {
        val name = binding.etAccountName.text.toString().trim()
        val bkash = binding.etBkashNumber.text.toString().trim()
        val nagad = binding.etNagadNumber.text.toString().trim()

        if (name.isBlank()) {
            Toast.makeText(this, "Account name is required", Toast.LENGTH_SHORT).show()
            return
        }
        if (bkash.isBlank() && nagad.isBlank()) {
            Toast.makeText(this, "At least one payment number required", Toast.LENGTH_SHORT).show()
            return
        }

        val integrationPin = binding.etIntegrationPin.text.toString().trim().let {
            if (it.length == 4 && it.all { c -> c.isDigit() }) it else "0000"
        }

        lifecycleScope.launch {
            val account = if (mode == "edit" && existingAccount != null) {
                existingAccount!!.copy(
                    accountName = name,
                    bkashNumber = bkash,
                    nagadNumber = nagad,
                    webhookUrl = binding.etWebhookUrl.text.toString().trim(),
                    webhookSecretKey = binding.etWebhookSecret.text.toString().trim(),
                    supabaseUrl = binding.etSupabaseUrl.text.toString().trim(),
                    supabaseAnonKey = binding.etSupabaseKey.text.toString().trim(),
                    integrationPin = integrationPin,
                    telegramBotToken = binding.etTelegramToken.text.toString().trim(),
                    telegramChatId = binding.etTelegramChatId.text.toString().trim()
                )
            } else {
                AccountEntity(
                    accountName = name,
                    bkashNumber = bkash,
                    nagadNumber = nagad,
                    webhookUrl = binding.etWebhookUrl.text.toString().trim(),
                    webhookSecretKey = binding.etWebhookSecret.text.toString().trim(),
                    supabaseUrl = binding.etSupabaseUrl.text.toString().trim(),
                    supabaseAnonKey = binding.etSupabaseKey.text.toString().trim(),
                    integrationPin = integrationPin,
                    telegramBotToken = binding.etTelegramToken.text.toString().trim(),
                    telegramChatId = binding.etTelegramChatId.text.toString().trim()
                )
            }

            if (mode == "edit") repo.update(account) else repo.insert(account)
            Toast.makeText(this@AccountEditActivity, "Account saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
