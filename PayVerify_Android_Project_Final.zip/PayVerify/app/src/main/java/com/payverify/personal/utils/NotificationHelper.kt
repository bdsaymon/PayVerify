package com.payverify.personal.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.payverify.personal.R
import com.payverify.personal.ui.accounts.AccountsActivity

object NotificationHelper {

    const val CHANNEL_VERIFIED = "channel_verified"
    const val CHANNEL_PENDING = "channel_pending"
    const val CHANNEL_DUPLICATE = "channel_duplicate"
    const val CHANNEL_SERVICE = "channel_service"

    fun createChannels(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val verifiedChannel = NotificationChannel(
            CHANNEL_VERIFIED,
            "Verified Payments",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifications for verified payment transactions"
            enableVibration(true)
        }

        val pendingChannel = NotificationChannel(
            CHANNEL_PENDING,
            "Pending Payments",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Notifications for pending unmatched SMS"
            enableVibration(false)
        }

        val duplicateChannel = NotificationChannel(
            CHANNEL_DUPLICATE,
            "Duplicate Transactions",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alerts for blocked duplicate transaction attempts"
            enableVibration(true)
        }

        val serviceChannel = NotificationChannel(
            CHANNEL_SERVICE,
            "SMS Listener Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent notification for background SMS monitoring"
        }

        manager.createNotificationChannels(listOf(verifiedChannel, pendingChannel, duplicateChannel, serviceChannel))
    }

    fun showVerifiedNotification(context: Context, accountName: String, txnId: String, amount: Double, gateway: String) {
        val intent = Intent(context, AccountsActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, CHANNEL_VERIFIED)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("✅ Payment Verified — $accountName")
            .setContentText("${gateway.uppercase()}: Tk $amount | TxnID: $txnId")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Gateway: ${gateway.uppercase()}\nAmount: Tk $amount\nTxnID: $txnId"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(txnId.hashCode(), notification)
    }

    fun showPendingNotification(context: Context, accountName: String, txnId: String, amount: Double, gateway: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_PENDING)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏳ Payment Received — $accountName")
            .setContentText("${gateway.uppercase()}: Tk $amount | TxnID: $txnId")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(txnId.hashCode() + 1, notification)
    }

    fun showDuplicateNotification(context: Context, txnId: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_DUPLICATE)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⛔ Duplicate Transaction Blocked")
            .setContentText("TxnID $txnId already exists. Rejected.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(txnId.hashCode() + 2, notification)
    }

    fun buildServiceNotification(context: Context) =
        NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(android.R.drawable.ic_menu_send)
            .setContentTitle("PayVerify Active")
            .setContentText("Monitoring bKash & Nagad SMS...")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
}
