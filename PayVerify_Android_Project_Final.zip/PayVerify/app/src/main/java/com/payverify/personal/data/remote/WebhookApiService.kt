package com.payverify.personal.data.remote

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

data class WebhookPayload(
    val txnId: String,
    val amount: Double,
    val sender: String,
    val gateway: String,
    val timestamp: Long,
    val accountId: String,
    val status: String
)

data class VerificationConfirmPayload(
    val orderId: String,
    val txnId: String,
    val amount: Double,
    val gateway: String,
    val status: String,
    val timestamp: Long
)

interface WebhookApiService {

    @POST
    suspend fun sendWebhook(
        @Url url: String,
        @Header("X-Webhook-Secret") secret: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Body payload: WebhookPayload
    ): retrofit2.Response<Unit>

    @POST
    suspend fun sendVerificationConfirm(
        @Url url: String,
        @Header("X-Webhook-Secret") secret: String,
        @Header("X-PayVerify-Key") apiKey: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Body payload: VerificationConfirmPayload
    ): retrofit2.Response<Unit>
}
