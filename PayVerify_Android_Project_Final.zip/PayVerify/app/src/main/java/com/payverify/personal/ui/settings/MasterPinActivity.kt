package com.payverify.personal.ui.settings

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.payverify.personal.databinding.ActivityPinEntryBinding
import com.payverify.personal.utils.SecurePrefs

class MasterPinActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinEntryBinding
    private var enteredPin = ""
    private var lockTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.tvTitle.text = "Master PIN"
        binding.tvSubtitle.text = "Enter your 4-digit admin PIN"

        if (SecurePrefs.isLocked(this)) {
            startLockCountdown()
        }

        setupKeypad()

        binding.btnConfirm.setOnClickListener { verifyPin() }
    }

    private fun setupKeypad() {
        val buttons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )
        buttons.forEachIndexed { index, btn ->
            btn.setOnClickListener {
                if (enteredPin.length < 4) {
                    enteredPin += index.toString()
                    updateDots()
                    if (enteredPin.length == 4) verifyPin()
                }
            }
        }
        binding.btnBackspace.setOnClickListener {
            if (enteredPin.isNotEmpty()) {
                enteredPin = enteredPin.dropLast(1)
                updateDots()
            }
        }
    }

    private fun updateDots() {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { i, dot ->
            dot.alpha = if (i < enteredPin.length) 1f else 0.3f
        }
    }

    private fun verifyPin() {
        if (SecurePrefs.isLocked(this)) {
            Toast.makeText(this, "Too many attempts. Wait.", Toast.LENGTH_SHORT).show()
            return
        }
        val correctPin = SecurePrefs.getMasterPin(this)
        if (enteredPin == correctPin) {
            SecurePrefs.setFailCount(this, 0)
            startActivity(Intent(this, SettingsActivity::class.java))
            finish()
        } else {
            val failCount = SecurePrefs.getFailCount(this) + 1
            SecurePrefs.setFailCount(this, failCount)
            enteredPin = ""
            updateDots()
            if (failCount >= 3) {
                val lockUntil = System.currentTimeMillis() + 30_000L
                SecurePrefs.setLockUntil(this, lockUntil)
                SecurePrefs.setFailCount(this, 0)
                startLockCountdown()
            } else {
                binding.tvError.text = "Wrong PIN. ${3 - failCount} attempt(s) left."
            }
        }
    }

    private fun startLockCountdown() {
        binding.btnConfirm.isEnabled = false
        lockTimer?.cancel()
        lockTimer = object : CountDownTimer(SecurePrefs.getRemainingLockSeconds(this) * 1000, 1000) {
            override fun onTick(ms: Long) {
                binding.tvError.text = "Locked. Try again in ${ms / 1000}s"
            }
            override fun onFinish() {
                binding.tvError.text = ""
                binding.btnConfirm.isEnabled = true
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        lockTimer?.cancel()
    }
}
