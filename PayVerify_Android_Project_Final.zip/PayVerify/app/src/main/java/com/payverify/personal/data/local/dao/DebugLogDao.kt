package com.payverify.personal.data.local.dao

import androidx.room.*
import com.payverify.personal.data.local.entities.DebugLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DebugLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: DebugLogEntity)

    @Query("SELECT * FROM debug_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentLogs(): Flow<List<DebugLogEntity>>

    @Query("DELETE FROM debug_logs")
    suspend fun clearAll()
}
