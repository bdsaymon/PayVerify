package com.payverify.personal.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val accountName: String,
    val bkashNumber: String,
    val nagadNumber: String,
    val webhookUrl: String = "",
    val webhookSecretKey: String = "",
    val supabaseUrl: String = "",
    val supabaseAnonKey: String = "",
    val integrationPin: String = "0000",
    val integrationApiKey: String = UUID.randomUUID().toString(),
    val telegramBotToken: String = "",
    val telegramChatId: String = "",
    val pendingTimeoutMinutes: Int = 10,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
