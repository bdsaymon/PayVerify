package com.payverify.personal.ui.accounts

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.payverify.personal.data.local.entities.AccountEntity
import com.payverify.personal.databinding.ItemAccountCardBinding

class AccountCardAdapter(
    private val onAccountClick: (AccountEntity) -> Unit,
    private val onEditClick: (AccountEntity) -> Unit,
    private val onDeleteClick: (AccountEntity) -> Unit,
    private val onToggleActive: (AccountEntity) -> Unit
) : ListAdapter<AccountEntity, AccountCardAdapter.ViewHolder>(DiffCallback()) {

    inner class ViewHolder(private val binding: ItemAccountCardBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(account: AccountEntity) {
            binding.tvAccountName.text = account.accountName
            binding.tvBkashNumber.text = "bKash: ${account.bkashNumber.ifBlank { "Not set" }}"
            binding.tvNagadNumber.text = "Nagad: ${account.nagadNumber.ifBlank { "Not set" }}"
            binding.tvStatus.text = if (account.isActive) "🟢 Active" else "🔴 Inactive"
            binding.root.setOnClickListener { onAccountClick(account) }
            binding.btnEdit.setOnClickListener { onEditClick(account) }
            binding.btnDelete.setOnClickListener { onDeleteClick(account) }
            binding.btnToggle.setOnClickListener { onToggleActive(account) }
            binding.btnToggle.text = if (account.isActive) "Deactivate" else "Activate"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAccountCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<AccountEntity>() {
        override fun areItemsTheSame(oldItem: AccountEntity, newItem: AccountEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: AccountEntity, newItem: AccountEntity) = oldItem == newItem
    }
}
