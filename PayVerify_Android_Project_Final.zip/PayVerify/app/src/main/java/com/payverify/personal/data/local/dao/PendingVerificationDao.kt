package com.payverify.personal.data.local.dao

import androidx.room.*
import com.payverify.personal.data.local.entities.PendingVerificationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingVerificationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pending: PendingVerificationEntity)

    @Update
    suspend fun update(pending: PendingVerificationEntity)

    @Query("SELECT * FROM pending_verifications WHERE accountId = :accountId ORDER BY createdAt DESC")
    fun getPendingByAccount(accountId: String): Flow<List<PendingVerificationEntity>>

    @Query("SELECT * FROM pending_verifications WHERE accountId = :accountId AND status = 'PENDING' AND expiresAt > :now")
    suspend fun getActivePending(accountId: String, now: Long = System.currentTimeMillis()): List<PendingVerificationEntity>

    @Query("SELECT * FROM pending_verifications WHERE accountId = :accountId AND expectedAmount = :amount AND gateway = :gateway AND status = 'PENDING' AND expiresAt > :now LIMIT 1")
    suspend fun findMatchingPending(accountId: String, amount: Double, gateway: String, now: Long = System.currentTimeMillis()): PendingVerificationEntity?

    @Query("UPDATE pending_verifications SET status = 'EXPIRED' WHERE status = 'PENDING' AND expiresAt <= :now")
    suspend fun expireOldPending(now: Long = System.currentTimeMillis())

    @Query("UPDATE pending_verifications SET status = :status, matchedTxnId = :txnId WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, txnId: String = "")

    @Query("SELECT COUNT(*) FROM pending_verifications WHERE accountId = :accountId AND status = 'PENDING'")
    fun getPendingCount(accountId: String): Flow<Int>
}
