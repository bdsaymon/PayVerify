package com.payverify.personal.ui.integration

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.payverify.personal.data.local.entities.AccountEntity
import com.payverify.personal.data.repository.AccountRepository
import com.payverify.personal.databinding.ActivityIntegrationHubBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID

class IntegrationHubActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIntegrationHubBinding
    private var account: AccountEntity? = null
    private val repo by lazy { AccountRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntegrationHubBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Integration Hub"

        val accountId = intent.getStringExtra("accountId") ?: run { finish(); return }

        lifecycleScope.launch {
            account = repo.getById(accountId)
            account?.let { renderHub(it) }
        }

        binding.btnCopyConfig.setOnClickListener {
            account?.let { copyConfigToClipboard(it) }
        }

        binding.btnTestPing.setOnClickListener {
            account?.let { testWebhook(it) }
        }

        binding.btnRegenKey.setOnClickListener {
            account?.let { acc ->
                lifecycleScope.launch {
                    val newKey = UUID.randomUUID().toString()
                    val updated = acc.copy(integrationApiKey = newKey)
                    repo.update(updated)
                    account = updated
                    renderHub(updated)
                    Toast.makeText(this@IntegrationHubActivity, "API Key regenerated!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun renderHub(acc: AccountEntity) {
        binding.tvAccountName.text = acc.accountName
        binding.tvStatus.text = if (acc.isActive) "🟢 Active" else "🔴 Inactive"
        binding.tvBkashNum.text = "bKash: ${acc.bkashNumber.ifBlank { "Not set" }}"
        binding.tvNagadNum.text = "Nagad: ${acc.nagadNumber.ifBlank { "Not set" }}"

        val config = buildConfig(acc)
        binding.tvConfigBlock.text = config
    }

    private fun buildConfig(acc: AccountEntity): String {
        return """
PAYVERIFY_ACCOUNT_ID=${acc.id}
PAYVERIFY_API_KEY=${acc.integrationApiKey}
PAYVERIFY_WEBHOOK_URL=${acc.webhookUrl.ifBlank { "https://your-webhook-url.com/payment/verify" }}
BKASH_NUMBER=${acc.bkashNumber.ifBlank { "Not configured" }}
NAGAD_NUMBER=${acc.nagadNumber.ifBlank { "Not configured" }}
        """.trimIndent()
    }

    private fun copyConfigToClipboard(acc: AccountEntity) {
        val config = buildConfig(acc)
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("PayVerify Integration Config", config)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "Config copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    private fun testWebhook(acc: AccountEntity) {
        if (acc.webhookUrl.isBlank()) {
            Toast.makeText(this, "Webhook URL not configured", Toast.LENGTH_SHORT).show()
            return
        }
        binding.tvTestResult.text = "Testing..."
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val client = OkHttpClient()
                    val request = Request.Builder()
                        .url(acc.webhookUrl)
                        .addHeader("X-PayVerify-Key", acc.integrationApiKey)
                        .addHeader("X-Webhook-Secret", acc.webhookSecretKey)
                        .get()
                        .build()
                    client.newCall(request).execute().code
                }
                binding.tvTestResult.text = if (result in 200..299) "✅ Connected ($result)" else "❌ Failed ($result)"
            } catch (e: Exception) {
                binding.tvTestResult.text = "❌ Error: ${e.message}"
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
